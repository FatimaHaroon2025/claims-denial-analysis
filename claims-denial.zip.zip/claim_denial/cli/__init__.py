"""Command‑line interface for the claim denial package.

This package exposes a small CLI program, ``claim-denial``, that allows
users to train, evaluate and perform inference with the claim denial model
from a terminal.  See ``cli.py`` for implementation details.
"""

from .cli import main  # noqa: F401

__all__ = ["main"]
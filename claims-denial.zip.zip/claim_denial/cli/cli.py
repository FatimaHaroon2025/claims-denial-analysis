"""Command‑line interface for the claim denial project.

This module defines a simple CLI using the built‑in :mod:`argparse`
module.  Users can train a model, evaluate an existing model or run
inference on an input string via subcommands.  For example::

    claim-denial train --model_name distilbert-base-uncased --output_dir my_output
    claim-denial evaluate --model_dir my_output/claim_denial_model
    claim-denial infer --model_dir my_output/claim_denial_model "A sample claim text"

Upon installation the ``setup.py`` entrypoint exposes this CLI as a
console script named ``claim-denial``.
"""

from __future__ import annotations

import argparse
from pprint import pprint
from typing import Optional

from ..model import train_model, evaluate_model, predict


def main(argv: Optional[list[str]] = None) -> None:
    """Entry point for the claim denial command‑line interface.

    This function parses command‑line arguments and dispatches to the
    appropriate subcommand implementation.  For ease of testing it
    accepts an optional list of arguments; when ``None`` (the default)
    arguments are read from ``sys.argv``.

    Args:
        argv: A list of argument strings to parse.  Defaults to ``None``
            which causes ``argparse`` to use ``sys.argv``.
    """
    parser = argparse.ArgumentParser(prog="claim-denial", description="Train and evaluate claim denial models")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # Train subcommand
    train_parser = subparsers.add_parser("train", help="Fine‑tune a pretrained model on the claim denial task")
    train_parser.add_argument(
        "--model_name",
        default="distilbert-base-uncased",
        help="Name or path of the pretrained model to fine‑tune",
    )
    train_parser.add_argument(
        "--data_path",
        default=None,
        help="Path to a CSV file containing labelled claims (optional)",
    )
    train_parser.add_argument(
        "--output_dir",
        default="outputs",
        help="Directory to save the fine‑tuned model and logs",
    )
    train_parser.add_argument("--epochs", type=int, default=3, help="Number of training epochs")
    train_parser.add_argument(
        "--train_batch_size",
        type=int,
        default=8,
        help="Batch size per device during training",
    )
    train_parser.add_argument(
        "--eval_batch_size",
        type=int,
        default=8,
        help="Batch size per device during evaluation",
    )
    train_parser.add_argument(
        "--learning_rate",
        type=float,
        default=5e-5,
        help="Learning rate for optimisation",
    )
    train_parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed for reproducibility",
    )

    # Evaluate subcommand
    eval_parser = subparsers.add_parser("evaluate", help="Evaluate a saved model on a dataset")
    eval_parser.add_argument("--model_dir", required=True, help="Directory containing the saved model")
    eval_parser.add_argument(
        "--data_path",
        default=None,
        help="Path to a CSV file for evaluation (optional)",
    )
    eval_parser.add_argument(
        "--split",
        default="test",
        choices=["train", "test"],
        help="Which split of the default dataset to evaluate on",
    )
    eval_parser.add_argument(
        "--batch_size",
        type=int,
        default=8,
        help="Batch size per device during evaluation",
    )

    # Inference subcommand
    infer_parser = subparsers.add_parser("infer", help="Run inference on a single text input")
    infer_parser.add_argument("--model_dir", required=True, help="Directory containing the saved model")
    infer_parser.add_argument("text", help="Text of the insurance claim to classify")

    args = parser.parse_args(argv)
    if args.command == "train":
        metrics = train_model(
            model_name=args.model_name,
            data_path=args.data_path,
            output_dir=args.output_dir,
            num_train_epochs=args.epochs,
            per_device_train_batch_size=args.train_batch_size,
            per_device_eval_batch_size=args.eval_batch_size,
            learning_rate=args.learning_rate,
            seed=args.seed,
        )
        print("Training completed. Evaluation metrics:")
        pprint(metrics)
    elif args.command == "evaluate":
        metrics = evaluate_model(
            model_dir=args.model_dir,
            data_path=args.data_path,
            split=args.split,
            batch_size=args.batch_size,
        )
        print("Evaluation metrics:")
        pprint(metrics)
    elif args.command == "infer":
        predictions = predict(args.model_dir, args.text)
        print("Prediction:")
        pprint(predictions)
    else:
        parser.print_help()
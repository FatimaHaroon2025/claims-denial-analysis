"""Top‑level package for the claim denial project.

This package exposes utilities for loading and preprocessing data, fine‑tuning
pretrained language models on an insurance claim denial classification task,
evaluating trained models and performing inference.  The functionality is
organized into three subpackages:

* ``data`` – routines for loading the dataset and splitting it into train and
  test splits.
* ``model`` – model training, baseline models, preprocessing, evaluation and
  inference.
* ``cli`` – an entrypoint that exposes the key functionality via a
  command‑line interface.

The package is intentionally lightweight; all heavy lifting such as model
downloads or fine‑tuning happens inside functions and is only executed when
these functions are called.  See the README for usage examples.
"""

__all__ = [
    "data",
    "model",
    "cli",
]
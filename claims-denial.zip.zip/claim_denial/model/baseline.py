"""Baseline model for claim denial classification.

This module defines a simple yet surprisingly competitive baseline for
binary text classification: a TF‑IDF vectoriser followed by a logistic
regression classifier.  When training large Transformer models is
impractical or undesirable, this baseline provides a quick sanity check.
"""

from __future__ import annotations

from typing import Sequence, Dict

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score


def train_baseline(
    train_texts: Sequence[str],
    train_labels: Sequence[int],
    test_texts: Sequence[str],
    test_labels: Sequence[int],
    max_features: int = 10_000,
    ngram_range: tuple = (1, 2),
    max_iter: int = 500,
) -> Dict[str, float]:
    """Train a TF‑IDF + logistic regression baseline and return metrics.

    Args:
        train_texts: List of training documents.
        train_labels: List of training labels (0 or 1).
        test_texts: List of evaluation documents.
        test_labels: List of evaluation labels.
        max_features: Maximum number of features to extract from the text.
        ngram_range: Tuple indicating the range of n‑gram sizes to consider.
        max_iter: Maximum number of iterations for the logistic regression
            optimiser.

    Returns:
        A dictionary containing the evaluation accuracy and F1 score on the
        test set.
    """
    # Vectorise texts with TF‑IDF.  We fit on the training data and reuse
    # the vocabulary for the test data.  Using bigrams improves recall of
    # common phrases in insurance claims (e.g. "pre existing", "coverage
    # denial").
    vectorizer = TfidfVectorizer(
        max_features=max_features,
        ngram_range=ngram_range,
        stop_words="english",
    )
    X_train = vectorizer.fit_transform(train_texts)
    X_test = vectorizer.transform(test_texts)

    # Train logistic regression classifier
    clf = LogisticRegression(max_iter=max_iter)
    clf.fit(X_train, train_labels)
    preds = clf.predict(X_test)

    # Compute simple metrics
    acc = accuracy_score(test_labels, preds)
    f1 = f1_score(test_labels, preds)
    return {"accuracy": acc, "f1": f1}
"""Utility functions for model training and evaluation.

Metrics play a central role in model training.  Rather than reimplement
accuracy and F1 calculation inside each training script, this module
provides a reusable ``compute_metrics`` function compatible with the
Hugging Face ``Trainer`` API.  Additional helpers can be added here as
needed.
"""

from __future__ import annotations

import numpy as np
import evaluate  # type: ignore

# Preload metrics only once for efficiency.  Evaluate caches metric
# definitions so repeated calls are inexpensive.
_accuracy_metric = evaluate.load("accuracy")
_f1_metric = evaluate.load("f1")


def compute_metrics(eval_pred: tuple[np.ndarray, np.ndarray]) -> dict:
    """Compute accuracy and weighted F1 score for classification.

    This function conforms to the signature expected by the Hugging Face
    ``Trainer`` API.  The predictions are provided as a tuple of logits
    and labels; we convert logits into predictions by taking the argmax
    across the last dimension, then compute accuracy and weighted F1.

    Args:
        eval_pred: A tuple ``(logits, labels)``.  ``logits`` should have
            shape ``(n_samples, n_classes)`` and ``labels`` should have
            shape ``(n_samples,)``.

    Returns:
        A dictionary with keys ``accuracy`` and ``f1`` containing the
        corresponding metric values.
    """
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    accuracy = _accuracy_metric.compute(predictions=preds, references=labels)["accuracy"]
    f1 = _f1_metric.compute(predictions=preds, references=labels, average="weighted")["f1"]
    return {"accuracy": accuracy, "f1": f1}
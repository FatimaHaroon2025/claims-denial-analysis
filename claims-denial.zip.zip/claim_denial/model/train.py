"""Training script for fine‑tuning a Transformer on the claim denial task.

This module provides a single entrypoint, ``train_model``, that wraps the
Hugging Face ``Trainer`` API to fine‑tune a pretrained language model on
the claim denial classification problem.  It handles loading and
preprocessing the data, initialising the model, configuring the training
hyperparameters and saving the resulting model and tokenizer.

The function returns a dictionary of evaluation metrics computed on the
validation set.  For reproducibility, pass explicit seeds to both
``train_test_split_data`` and the ``TrainingArguments`` constructor.
"""

from __future__ import annotations

import os
from typing import Optional

import pandas as pd
import torch
from transformers import (
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
)

from ..data import load_data, train_test_split_data
from .preprocess import get_tokenizer, tokenize_dataset
from .utils import compute_metrics


def train_model(
    model_name: str = "distilbert-base-uncased",
    data_path: Optional[str] = None,
    output_dir: str = "outputs",
    num_train_epochs: int = 3,
    per_device_train_batch_size: int = 8,
    per_device_eval_batch_size: int = 8,
    learning_rate: float = 5e-5,
    seed: int = 42,
    logging_steps: int = 50,
) -> dict:
    """Fine‑tune a pretrained model on the claim denial dataset.

    Args:
        model_name: Name or path of the pretrained model to fine‑tune.  Any
            model available in the Hugging Face model hub that supports
            sequence classification should work.
        data_path: Optional path to a CSV file containing labelled data.  If
            omitted the default dataset is downloaded from the Hugging Face
            Hub.
        output_dir: Directory to save the fine‑tuned model and logs.
        num_train_epochs: Number of epochs to train for.
        per_device_train_batch_size: Batch size used during training.
        per_device_eval_batch_size: Batch size used during evaluation.
        learning_rate: Learning rate for the optimiser.
        seed: Random seed for data splitting and Trainer.
        logging_steps: Number of update steps between two logs.

    Returns:
        A dictionary containing the evaluation metrics on the validation set.
    """
    # Load the raw data as a pandas DataFrame
    df = load_data(data_path)
    # Split into train and test lists.  We keep a holdout split to
    # evaluate performance mid‑training.  For a final model you might want
    # to merge the splits and perform cross‑validation.
    train_texts, test_texts, train_labels, test_labels = train_test_split_data(
        df, test_size=0.1, seed=seed
    )
    # Convert lists back into DataFrames for tokenisation
    train_df = pd.DataFrame(
        {"claim_text": train_texts, "denial_label": train_labels}
    )
    test_df = pd.DataFrame(
        {"claim_text": test_texts, "denial_label": test_labels}
    )

    # Load a tokenizer appropriate for the model
    tokenizer = get_tokenizer(model_name)

    # Tokenise datasets
    train_dataset = tokenize_dataset(train_df, tokenizer)
    eval_dataset = tokenize_dataset(test_df, tokenizer)

    # Determine the number of labels from the data
    num_labels = len(set(df["denial_label"]))

    # Load the model.  The number of labels must match the dataset.
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=num_labels
    )

    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)

    # Create training arguments.  We set evaluation and saving strategy
    # based on epoch boundaries to allow metric calculation each epoch.
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=num_train_epochs,
        per_device_train_batch_size=per_device_train_batch_size,
        per_device_eval_batch_size=per_device_eval_batch_size,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        learning_rate=learning_rate,
        logging_dir=os.path.join(output_dir, "logs"),
        logging_steps=logging_steps,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        seed=seed,
        report_to=[],
    )

    # Create the Trainer.  Pass in our compute_metrics function so that
    # accuracy and F1 are computed during evaluation.
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        compute_metrics=compute_metrics,
    )

    # Train the model.  For large models this will take significant time
    # and resources; adjust hyperparameters accordingly.  In this context
    # we do not catch exceptions so that any training failures surface to
    # the caller.
    trainer.train()

    # Save the model and tokenizer to the specified directory.  We use a
    # subdirectory named ``claim_denial_model`` to group the files neatly.
    save_path = os.path.join(output_dir, "claim_denial_model")
    trainer.save_model(save_path)
    tokenizer.save_pretrained(save_path)

    # Evaluate on the validation split and return the metrics.  The
    # ``Trainer.evaluate`` method returns a dictionary containing all
    # metrics tracked during training; accuracy and F1 come from
    # ``compute_metrics``.
    metrics = trainer.evaluate()
    return metrics
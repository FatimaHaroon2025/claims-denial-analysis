"""Module for evaluating fine‑tuned claim denial models.

The purpose of this module is to streamline evaluation of a saved
Transformer model on a given dataset.  Loading the model and tokenizer
from disk is handled automatically.  The function returns metrics that
mirror those computed during training (accuracy and F1).  Users can
specify an alternate dataset via ``data_path`` or evaluate on the
default dataset downloaded from the Hub.
"""

from __future__ import annotations

import os
from typing import Optional

import pandas as pd
from transformers import AutoModelForSequenceClassification, Trainer, TrainingArguments

from ..data import load_data
from .preprocess import get_tokenizer, tokenize_dataset
from .utils import compute_metrics


def evaluate_model(
    model_dir: str,
    data_path: Optional[str] = None,
    split: str = "test",
    batch_size: int = 8,
) -> dict:
    """Evaluate a fine‑tuned model on a dataset and return metrics.

    Args:
        model_dir: Directory containing the saved ``pytorch_model.bin`` and
            associated config files.  This should correspond to the
            directory created by ``train_model``.
        data_path: Optional path to a CSV file for evaluation.  When
            ``None``, the default dataset is downloaded from the Hugging
            Face Hub.
        split: Which split of the dataset to evaluate on when using the
            Hugging Face Hub.  Ignored if ``data_path`` is provided.
        batch_size: Batch size to use during evaluation.

    Returns:
        A dictionary containing the evaluation metrics.
    """
    # Load evaluation data
    df = load_data(data_path, split=split)

    # Prepare dataset for model consumption
    tokenizer = get_tokenizer(model_dir)
    eval_dataset = tokenize_dataset(df, tokenizer)

    # Load model from disk
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)

    # Configure Trainer for evaluation only
    training_args = TrainingArguments(
        output_dir=os.path.join(model_dir, "eval_tmp"),
        per_device_eval_batch_size=batch_size,
        report_to=[],
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        eval_dataset=eval_dataset,
        compute_metrics=compute_metrics,
    )

    metrics = trainer.evaluate()
    return metrics
"""Tokenisation and dataset preparation utilities.

Transformers require that text be converted into a sequence of input IDs
and associated attention masks.  This module wraps the Hugging Face
tokenisers and provides convenience functions to apply them to entire
datasets represented as pandas dataframes.  The resulting datasets are
returned in Hugging Face ``datasets.Dataset`` format with PyTorch
tensors, ready for consumption by the ``Trainer`` API.
"""

from __future__ import annotations

from typing import Any

import pandas as pd

from transformers import AutoTokenizer
from datasets import Dataset  # type: ignore


def get_tokenizer(model_name: str, **kwargs: Any) -> AutoTokenizer:
    """Load a pretrained tokenizer by name.

    This simply calls ``AutoTokenizer.from_pretrained`` and passes through
    any keyword arguments.  See the Hugging Face documentation for
    available arguments.

    Args:
        model_name: The name or path of the pretrained model whose tokenizer
            should be loaded.
        **kwargs: Additional keyword arguments forwarded to
            ``AutoTokenizer.from_pretrained``.

    Returns:
        An ``AutoTokenizer`` instance.
    """
    return AutoTokenizer.from_pretrained(model_name, **kwargs)


def tokenize_dataset(
    df: pd.DataFrame,
    tokenizer: AutoTokenizer,
    max_length: int = 256,
    remove_columns: bool = True,
) -> Dataset:
    """Tokenise a dataframe of claim texts into a Hugging Face dataset.

    The returned dataset will contain the following fields:

    * ``input_ids`` – token IDs
    * ``attention_mask`` – attention mask for padded elements
    * ``labels`` – integer labels corresponding to the claim outcome

    Args:
        df: Dataframe with at least ``claim_text`` and ``denial_label``
            columns.
        tokenizer: A Hugging Face tokenizer.
        max_length: Maximum token length; texts longer than this will be
            truncated and shorter texts padded.
        remove_columns: Whether to remove the original ``claim_text`` and
            ``denial_label`` columns from the returned dataset.

    Returns:
        A ``datasets.Dataset`` with tokenised inputs and labels.
    """
    if "claim_text" not in df.columns or "denial_label" not in df.columns:
        raise ValueError("Dataframe must contain 'claim_text' and 'denial_label' columns")

    raw_dataset = Dataset.from_pandas(df)

    def _tokenize(batch):
        return tokenizer(
            batch["claim_text"],
            padding="max_length",
            truncation=True,
            max_length=max_length,
        )

    tokenized = raw_dataset.map(_tokenize, batched=True)
    # rename target column to labels for HF Trainer
    tokenized = tokenized.rename_column("denial_label", "labels")
    # remove superfluous columns
    if remove_columns:
        tokenized = tokenized.remove_columns([col for col in tokenized.column_names if col not in {"input_ids", "attention_mask", "labels"}])
    tokenized.set_format(type="torch", columns=["input_ids", "attention_mask", "labels"])
    return tokenized
"""Model utilities for the claim denial project.

This subpackage encapsulates all operations related to modelling: data
preprocessing and tokenisation, training and evaluating both simple
baselines and Transformer models, and performing inference with trained
models.  Most functions in this module are pure and stateless; stateful
objects such as Transformers are created within functions and disposed of
afterwards.
"""

from .baseline import train_baseline  # noqa: F401
from .preprocess import get_tokenizer, tokenize_dataset  # noqa: F401
from .train import train_model  # noqa: F401
from .evaluate import evaluate_model  # noqa: F401
from .infer import predict  # noqa: F401

__all__ = [
    "train_baseline",
    "get_tokenizer",
    "tokenize_dataset",
    "train_model",
    "evaluate_model",
    "predict",
]
"""Inference utilities for the claim denial model.

This module exposes a simple ``predict`` function that wraps the Hugging
Face ``pipeline`` for text classification.  Given a saved model
directory and a text string, it returns the model's predicted label and
score.  The device is automatically chosen based on GPU availability.
"""

from __future__ import annotations

from typing import Any, Dict, List

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer, pipeline


def predict(model_dir: str, text: str) -> List[Dict[str, Any]]:
    """Run inference on a single piece of text using a trained model.

    Args:
        model_dir: Path to the directory containing the saved model and
            tokenizer (created by ``train_model``).
        text: A single string containing the claim text to classify.

    Returns:
        A list of dictionaries containing the label and score, consistent
        with the output of ``transformers.pipeline``.
    """
    # Load model and tokenizer from the specified directory
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    device = 0 if torch.cuda.is_available() else -1
    clf = pipeline(
        "text-classification",
        model=model,
        tokenizer=tokenizer,
        device=device,
    )
    return clf(text)
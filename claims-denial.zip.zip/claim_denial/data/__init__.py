"""Data loading utilities for the claim denial project.

This subpackage contains helper functions to load the insurance claim
classification dataset from various sources.  Data can be loaded from a
comma‑separated values (CSV) file on disk or downloaded from the Hugging
Face Hub.  The dataset is filtered to English language examples and
preprocessed into train/test splits ready for modeling.
"""

from .data import load_data, train_test_split_data  # noqa: F401

__all__ = ["load_data", "train_test_split_data"]
"""Functions for loading and preparing data for the claim denial model.

The insurance claim denial project is built around a publicly available
dataset hosted on the Hugging Face Hub.  This module provides helpers to
download and preprocess that dataset, as well as to read data from a
user‑supplied CSV file.  The data is filtered to English language claims
using the `langdetect` library and split into training and test sets using
scikit‑learn.
"""

from __future__ import annotations

import os
from typing import Optional, Sequence, Tuple

import pandas as pd
from sklearn.model_selection import train_test_split

try:
    # ``datasets`` is an optional dependency; it is only needed when
    # downloading from the Hugging Face Hub.  We import lazily so that
    # environments without the library installed can still use the CSV
    # loading functionality without error.  If import fails here and the
    # user asks to download the default dataset, a more helpful error is
    # raised in ``load_data``.
    from datasets import load_dataset  # type: ignore
except Exception:  # pragma: no cover - datasets may not be installed
    load_dataset = None  # type: ignore

try:
    from langdetect import detect  # type: ignore
except Exception:  # pragma: no cover - langdetect may not be installed
    detect = None  # type: ignore


def _is_english(text: str) -> bool:
    """Detect whether a piece of text is written in English.

    This helper wraps ``langdetect.detect`` to provide a safe fallback when
    the package is unavailable.  When `langdetect` is not installed the
    function will simply return ``True`` for all inputs, meaning that no
    filtering will occur.

    Args:
        text: The text to detect.

    Returns:
        ``True`` if the text is detected as English, otherwise ``False``.  If
        the ``langdetect`` package is not installed this always returns
        ``True``.
    """
    if detect is None:
        # No language detection available; assume English
        return True
    try:
        return detect(text) == "en"
    except Exception:
        return False


def load_data(
    data_path: Optional[str] = None,
    dataset_name: str = "designfailure/my-agentic-InsurTech",
    split: str = "train",
    cache_dir: Optional[str] = None,
) -> pd.DataFrame:
    """Load claim denial data from a CSV file or the Hugging Face Hub.

    There are two primary modes of operation:

    1. When ``data_path`` is supplied this function reads a comma‑separated
       values (CSV) file from that location.  The file must contain at
       least two columns: ``claim_text`` and ``denial_label``.
    2. When ``data_path`` is ``None``, the function attempts to download
       the default dataset from the Hugging Face Hub using the
       ``datasets`` library.  If the library is not installed a helpful
       ``ImportError`` is raised.

    Regardless of the source, the loaded data is filtered to include only
    English language examples (if the ``langdetect`` package is available).
    Column names are standardised to ``claim_text`` and ``denial_label``.

    Args:
        data_path: Optional path to a CSV file containing labelled claims.
        dataset_name: Name of the dataset to download from the hub when
            ``data_path`` is not provided.
        split: Which split of the dataset to return (``"train"`` or
            ``"test"``).  This argument is ignored when ``data_path`` is
            given.
        cache_dir: Optional directory to cache the downloaded dataset.

    Returns:
        A ``pandas.DataFrame`` with two columns: ``claim_text`` and
        ``denial_label``.

    Raises:
        FileNotFoundError: If ``data_path`` is provided but no file exists
            at that location.
        ImportError: If ``data_path`` is ``None`` but the ``datasets``
            library is not installed.
    """
    if data_path:
        if not os.path.exists(data_path):
            raise FileNotFoundError(f"CSV file not found at {data_path!r}")
        df = pd.read_csv(data_path)
        # Expect typical column names; rename if necessary
        col_map = {}
        for col in df.columns:
            lower = col.lower().strip()
            if lower == "text":
                col_map[col] = "claim_text"
            elif lower == "label" or lower == "denial" or lower == "denial_label":
                col_map[col] = "denial_label"
        df = df.rename(columns=col_map)
        if "claim_text" not in df.columns or "denial_label" not in df.columns:
            raise ValueError(
                "CSV file must contain 'claim_text' and 'denial_label' columns"
            )
    else:
        # Download from the Hugging Face Hub
        if load_dataset is None:
            raise ImportError(
                "datasets library is required to download data from the Hugging Face Hub"
            )
        ds = load_dataset(dataset_name, split=split, cache_dir=cache_dir)
        # Standardise column names
        if "text" in ds.column_names:
            ds = ds.rename_column("text", "claim_text")
        if "label" in ds.column_names:
            ds = ds.rename_column("label", "denial_label")
        # filter to english using langdetect
        ds = ds.filter(lambda example: _is_english(example["claim_text"]))
        df = pd.DataFrame(
            {
                "claim_text": ds["claim_text"],
                "denial_label": ds["denial_label"],
            }
        )
    # Reset index and ensure correct dtypes
    df = df.reset_index(drop=True)
    df["denial_label"] = df["denial_label"].astype(int)
    return df


def train_test_split_data(
    df: pd.DataFrame,
    test_size: float = 0.1,
    seed: int = 42,
) -> Tuple[Sequence[str], Sequence[str], Sequence[int], Sequence[int]]:
    """Split the data into training and testing subsets.

    This helper wraps ``sklearn.model_selection.train_test_split`` to produce
    lists of texts and labels for ease of use downstream.  Stratified
    sampling is used to preserve the class distribution across splits.

    Args:
        df: A dataframe with at least ``claim_text`` and ``denial_label``
            columns.
        test_size: Fraction of the data to allocate to the test set.
        seed: Random seed for reproducibility.

    Returns:
        A tuple ``(train_texts, test_texts, train_labels, test_labels)``.
    """
    if "claim_text" not in df.columns or "denial_label" not in df.columns:
        raise ValueError("Dataframe must contain 'claim_text' and 'denial_label' columns")
    train_texts, test_texts, train_labels, test_labels = train_test_split(
        df["claim_text"].tolist(),
        df["denial_label"].tolist(),
        test_size=test_size,
        random_state=seed,
        stratify=df["denial_label"],
    )
    return train_texts, test_texts, train_labels, test_labels